window.addEventListener('DOMContentLoaded',function(e){
    let load= new Homepage();
});